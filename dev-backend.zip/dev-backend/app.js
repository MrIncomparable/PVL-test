const MongoClient = require('mongodb').MongoClient;
const port = 8000;
var express = require("express");
var bodyParser = require('body-parser');
var male = 120;
var female = 110;
var boy = 90;
var girl = 10;

var app = express(); app.listen(port, () => {
    console.log("Server running on port 8000");
});

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'DELETE, PUT');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    if ('OPTIONS' == req.method) {
        res.sendStatus(200);
    }
    else {
        next();
    }
});

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json())


app.get("/getAll", (req, res, next) => {
    res.json([male, female, boy, girl]);
});

app.put('/setAll', function (req, res) {
    console.log(req.body);
    response = {
        male: req.body.male,
        female: req.body.female,
        boy: req.body.boy,
        girl: req.body.girl,
    };

    male = req.body.male;
    female = req.body.female;
    boy = req.body.boy;
    girl = req.body.girl;
    console.log(response);
    res.end(JSON.stringify(response));
})  