import male from './male.png';
import female from './female.png';
import boy from './boy.png';
import girl from './girl.png';
import { useState, useEffect } from 'react';
import { PieChart } from 'react-minimal-pie-chart';
import './App.css';

function TopButton({ tabName, selectedTopBar, setSelectedTopBar, topBarNumber }) {
  return (<div
    onClick={() => setSelectedTopBar(topBarNumber)}
    style={{
      width: "100px",
      height: "50px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: selectedTopBar === topBarNumber ? "white" : "grey"
    }}>{tabName}</div>);
}


function App() {
  const [maleMessage, setMaleMessage] = useState('10');
  const [femaleMessage, setFemaleMessage] = useState('10');
  const [boyMessage, setBoyMessage] = useState('10');
  const [girlMessage, setGirlMessage] = useState('10');

  const handleMaleChange = event => {
    setMaleMessage(event.target.value);
  }
  const handleFemaleChange = event => {
    setFemaleMessage(event.target.value);
  }
  const handleBoyChange = event => {
    setBoyMessage(event.target.value);
  }
  const handleGirlChange = event => {
    setGirlMessage(event.target.value);
  }

  useEffect(() => {
    fetch('http://localhost:8000/getAll')
      .then((res) => res.json())
      .then((data) => {
        console.log(data);
        setMaleMessage(data[0].toString());
        setFemaleMessage(data[1].toString());
        setBoyMessage(data[2].toString());
        setGirlMessage(data[3].toString());
      })
      .catch((err) => {
        console.log(err.message);
      });
  }, []);


  var [selectedTopBar, setSelectedTopBar] = useState(0);
  return (
    <div className="App">
      <div
        style={{
          width: "100%",
          height: "50px",
          backgroundColor: "black",
          display: "flex",
          alignItems: "center",

        }}>
        <TopButton tabName={"Company"} selectedTopBar={selectedTopBar} setSelectedTopBar={setSelectedTopBar} topBarNumber={0} />
        <TopButton tabName={"People"} selectedTopBar={selectedTopBar} setSelectedTopBar={setSelectedTopBar} topBarNumber={1} />
        <TopButton tabName={"Visitor"} selectedTopBar={selectedTopBar} setSelectedTopBar={setSelectedTopBar} topBarNumber={2} />
        <TopButton tabName={"Settings"} selectedTopBar={selectedTopBar} setSelectedTopBar={setSelectedTopBar} topBarNumber={3} />
      </div>
      <div
        style={{
          marginTop: "20px",
          marginBottom: "20px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}>
        <div style={{
          marginLeft: "20px",
          marginRight: "20px"
        }}>
          <div>
            <img src={male} style={{
              height: "50px", width: "50px"
            }} ></img>
          </div>
          <input
            style={{
              width: "50px"
            }}
            onChange={handleMaleChange}
            value={maleMessage}
          ></input>
        </div>
        <div style={{
          marginLeft: "20px",
          marginRight: "20px"
        }}>
          <div>
            <img src={female} style={{
              height: "50px", width: "50px"
            }} ></img>
          </div>
          <input
            style={{
              width: "50px"
            }}
            onChange={handleFemaleChange}
            value={femaleMessage}
          ></input>
        </div>
        <div style={{
          marginLeft: "20px",
          marginRight: "20px"
        }}>
          <div>
            <img src={boy} style={{
              height: "50px", width: "50px"
            }} ></img>
          </div>
          <input
            style={{
              width: "50px"
            }}
            onChange={handleBoyChange}
            value={boyMessage}
          ></input>
        </div>
        <div style={{
          marginLeft: "20px",
          marginRight: "20px"
        }}>
          <div>
            <img src={girl} style={{
              height: "50px", width: "50px"
            }} ></img>
          </div>
          <input
            style={{
              width: "50px"
            }}
            onChange={handleGirlChange}
            value={girlMessage}
          ></input>
        </div>
      </div>
      {selectedTopBar === 3 ? <div style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }}>
        <div style={{
          backgroundColor: "blue",
          width: "100px",
          height: "50px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "white"
        }}>
          Submit
        </div>
      </div> : <PieChart
        style={{
          width: "150px",
          height: "150px",
        }}
        data={[
          { title: 'Men', value: parseInt(maleMessage), color: '#E38627' },
          { title: 'Women', value: parseInt(femaleMessage), color: '#C13C37' },
          { title: 'Boy', value: parseInt(boyMessage), color: '#6A2135' },
          { title: 'Girl', value: parseInt(girlMessage), color: 'red' },
        ]}
      />
      }
    </div>
  );
}

export default App;
